import { Router } from 'express';
import {
  getLeads,
  getLead,
  createLead,
  updateLead,
  deleteLead,
  exportLeadsCSV,
  getLeadStats,
} from '../controllers/leadsController';
import { authenticate, authorize } from '../middleware/auth';
import { leadValidation, updateLeadValidation } from '../middleware/validation';

const router = Router();

// All routes require authentication
router.use(authenticate);

router.get('/export', exportLeadsCSV);
router.get('/stats', getLeadStats);
router.get('/', getLeads);
router.get('/:id', getLead);
router.post('/', leadValidation, createLead);
router.put('/:id', updateLeadValidation, updateLead);
router.delete('/:id', authorize('admin'), deleteLead);

export default router;
