import { Response } from 'express';
import { FilterQuery } from 'mongoose';
import { Lead, ILeadDocument } from '../models/Lead';
import { sendSuccess, sendError, buildPaginationMeta } from '../utils/response';
import { AuthRequest, LeadFilters, LeadStatus, LeadSource } from '../types';

export const getLeads = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const {
      status,
      source,
      search,
      sort = 'latest',
      page = '1',
      limit = '10',
    } = req.query as {
      status?: string;
      source?: string;
      search?: string;
      sort?: string;
      page?: string;
      limit?: string;
    };

    const pageNum = Math.max(1, parseInt(page, 10));
    const limitNum = Math.min(100, Math.max(1, parseInt(limit, 10)));
    const skip = (pageNum - 1) * limitNum;

    const filter: FilterQuery<ILeadDocument> = {};

    // Role-based: sales users only see their own leads
    if (req.user?.role === 'sales') {
      filter.createdBy = req.user.id;
    }

    if (status && ['New', 'Contacted', 'Qualified', 'Lost'].includes(status)) {
      filter.status = status as LeadStatus;
    }

    if (source && ['Website', 'Instagram', 'Referral'].includes(source)) {
      filter.source = source as LeadSource;
    }

    if (search && search.trim()) {
      const searchRegex = new RegExp(search.trim(), 'i');
      filter.$or = [{ name: searchRegex }, { email: searchRegex }];
    }

    const sortOrder = sort === 'oldest' ? 1 : -1;

    const [leads, total] = await Promise.all([
      Lead.find(filter)
        .populate('createdBy', 'name email role')
        .populate('assignedTo', 'name email role')
        .sort({ createdAt: sortOrder })
        .skip(skip)
        .limit(limitNum),
      Lead.countDocuments(filter),
    ]);

    const meta = buildPaginationMeta(total, pageNum, limitNum);
    sendSuccess(res, { leads }, 'Leads fetched successfully', 200, meta);
  } catch {
    sendError(res, 'Failed to fetch leads', 500);
  }
};

export const getLead = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const filter: FilterQuery<ILeadDocument> = { _id: req.params.id };

    if (req.user?.role === 'sales') {
      filter.createdBy = req.user.id;
    }

    const lead = await Lead.findOne(filter)
      .populate('createdBy', 'name email role')
      .populate('assignedTo', 'name email role');

    if (!lead) {
      sendError(res, 'Lead not found', 404);
      return;
    }

    sendSuccess(res, { lead });
  } catch {
    sendError(res, 'Failed to fetch lead', 500);
  }
};

export const createLead = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { name, email, status, source, notes, assignedTo } = req.body as {
      name: string;
      email: string;
      status?: LeadStatus;
      source: LeadSource;
      notes?: string;
      assignedTo?: string;
    };

    const lead = await Lead.create({
      name,
      email,
      status: status ?? 'New',
      source,
      notes,
      assignedTo: assignedTo ?? undefined,
      createdBy: req.user?.id,
    });

    const populated = await lead.populate('createdBy', 'name email role');

    sendSuccess(res, { lead: populated }, 'Lead created successfully', 201);
  } catch {
    sendError(res, 'Failed to create lead', 500);
  }
};

export const updateLead = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const filter: FilterQuery<ILeadDocument> = { _id: req.params.id };

    // Sales users can only update their own leads
    if (req.user?.role === 'sales') {
      filter.createdBy = req.user.id;
    }

    const lead = await Lead.findOneAndUpdate(
      filter,
      { $set: req.body },
      { new: true, runValidators: true }
    )
      .populate('createdBy', 'name email role')
      .populate('assignedTo', 'name email role');

    if (!lead) {
      sendError(res, 'Lead not found or unauthorized', 404);
      return;
    }

    sendSuccess(res, { lead }, 'Lead updated successfully');
  } catch {
    sendError(res, 'Failed to update lead', 500);
  }
};

export const deleteLead = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    // Only admin can delete leads
    const lead = await Lead.findByIdAndDelete(req.params.id);

    if (!lead) {
      sendError(res, 'Lead not found', 404);
      return;
    }

    sendSuccess(res, null, 'Lead deleted successfully');
  } catch {
    sendError(res, 'Failed to delete lead', 500);
  }
};

export const exportLeadsCSV = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const filter: FilterQuery<ILeadDocument> = {};

    if (req.user?.role === 'sales') {
      filter.createdBy = req.user.id;
    }

    const { status, source, search } = req.query as {
      status?: string;
      source?: string;
      search?: string;
    };

    if (status && ['New', 'Contacted', 'Qualified', 'Lost'].includes(status)) {
      filter.status = status as LeadStatus;
    }
    if (source && ['Website', 'Instagram', 'Referral'].includes(source)) {
      filter.source = source as LeadSource;
    }
    if (search?.trim()) {
      const searchRegex = new RegExp(search.trim(), 'i');
      filter.$or = [{ name: searchRegex }, { email: searchRegex }];
    }

    const leads = await Lead.find(filter)
      .populate('createdBy', 'name email')
      .sort({ createdAt: -1 });

    const headers = ['Name', 'Email', 'Status', 'Source', 'Notes', 'Created At'];
    const rows = leads.map((lead) => [
      `"${lead.name}"`,
      `"${lead.email}"`,
      `"${lead.status}"`,
      `"${lead.source}"`,
      `"${lead.notes ?? ''}"`,
      `"${new Date(lead.createdAt).toISOString()}"`,
    ]);

    const csv = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');

    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', 'attachment; filename=leads.csv');
    res.status(200).send(csv);
  } catch {
    sendError(res, 'Failed to export leads', 500);
  }
};

export const getLeadStats = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const filter: FilterQuery<ILeadDocument> = {};
    if (req.user?.role === 'sales') {
      filter.createdBy = req.user.id;
    }

    const [statusStats, sourceStats, total] = await Promise.all([
      Lead.aggregate([
        { $match: filter },
        { $group: { _id: '$status', count: { $sum: 1 } } },
      ]),
      Lead.aggregate([
        { $match: filter },
        { $group: { _id: '$source', count: { $sum: 1 } } },
      ]),
      Lead.countDocuments(filter),
    ]);

    sendSuccess(res, { total, statusStats, sourceStats });
  } catch {
    sendError(res, 'Failed to fetch stats', 500);
  }
};
