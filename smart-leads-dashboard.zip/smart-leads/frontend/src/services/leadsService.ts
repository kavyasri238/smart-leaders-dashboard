import api from './api';
import { ApiResponse, Lead, LeadFilters, LeadFormData, LeadStats } from '../types';

export const leadsService = {
  getLeads: async (
    filters: LeadFilters
  ): Promise<ApiResponse<{ leads: Lead[] }>> => {
    const params = new URLSearchParams();
    if (filters.status) params.append('status', filters.status);
    if (filters.source) params.append('source', filters.source);
    if (filters.search) params.append('search', filters.search);
    if (filters.sort) params.append('sort', filters.sort);
    if (filters.page) params.append('page', String(filters.page));
    if (filters.limit) params.append('limit', String(filters.limit));

    const res = await api.get<ApiResponse<{ leads: Lead[] }>>(
      `/leads?${params.toString()}`
    );
    return res.data;
  },

  getLead: async (id: string): Promise<ApiResponse<{ lead: Lead }>> => {
    const res = await api.get<ApiResponse<{ lead: Lead }>>(`/leads/${id}`);
    return res.data;
  },

  createLead: async (
    data: LeadFormData
  ): Promise<ApiResponse<{ lead: Lead }>> => {
    const res = await api.post<ApiResponse<{ lead: Lead }>>('/leads', data);
    return res.data;
  },

  updateLead: async (
    id: string,
    data: Partial<LeadFormData>
  ): Promise<ApiResponse<{ lead: Lead }>> => {
    const res = await api.put<ApiResponse<{ lead: Lead }>>(
      `/leads/${id}`,
      data
    );
    return res.data;
  },

  deleteLead: async (id: string): Promise<ApiResponse<null>> => {
    const res = await api.delete<ApiResponse<null>>(`/leads/${id}`);
    return res.data;
  },

  exportCSV: (filters: Omit<LeadFilters, 'page' | 'limit'>): void => {
    const params = new URLSearchParams();
    if (filters.status) params.append('status', filters.status);
    if (filters.source) params.append('source', filters.source);
    if (filters.search) params.append('search', filters.search);

    const token = localStorage.getItem('token');
    const url = `${import.meta.env.VITE_API_URL ?? '/api'}/leads/export?${params.toString()}`;

    // Create a temporary link to trigger download with auth header
    fetch(url, {
      headers: { Authorization: `Bearer ${token ?? ''}` },
    })
      .then((res) => res.blob())
      .then((blob) => {
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = 'leads.csv';
        link.click();
        URL.revokeObjectURL(link.href);
      })
      .catch(console.error);
  },

  getStats: async (): Promise<ApiResponse<LeadStats>> => {
    const res = await api.get<ApiResponse<LeadStats>>('/leads/stats');
    return res.data;
  },
};
