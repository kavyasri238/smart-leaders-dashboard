import api from './api';
import { ApiResponse, User } from '../types';

interface AuthData {
  user: User;
  token: string;
}

export const authService = {
  register: async (data: {
    name: string;
    email: string;
    password: string;
    role?: string;
  }): Promise<ApiResponse<AuthData>> => {
    const res = await api.post<ApiResponse<AuthData>>('/auth/register', data);
    return res.data;
  },

  login: async (data: {
    email: string;
    password: string;
  }): Promise<ApiResponse<AuthData>> => {
    const res = await api.post<ApiResponse<AuthData>>('/auth/login', data);
    return res.data;
  },

  getMe: async (): Promise<ApiResponse<{ user: User }>> => {
    const res = await api.get<ApiResponse<{ user: User }>>('/auth/me');
    return res.data;
  },

  getUsers: async (): Promise<ApiResponse<{ users: User[] }>> => {
    const res = await api.get<ApiResponse<{ users: User[] }>>('/auth/users');
    return res.data;
  },
};
