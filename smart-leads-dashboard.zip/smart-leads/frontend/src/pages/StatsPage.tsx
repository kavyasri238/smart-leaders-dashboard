import React, { useEffect, useState } from 'react';
import { TrendingUp, Users, Target, XCircle, Globe, Instagram, Share2 } from 'lucide-react';
import { leadsService } from '../services/leadsService';
import { LeadStats } from '../types';
import { Spinner } from '../components/ui/Spinner';

const StatsPage: React.FC = () => {
  const [stats, setStats] = useState<LeadStats | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const res = await leadsService.getStats();
        if (res.success && res.data) setStats(res.data);
      } catch {
        // silently fail
      } finally {
        setIsLoading(false);
      }
    };
    fetchStats();
  }, []);

  const statusConfig: Record<string, { label: string; color: string; bgColor: string; icon: React.ElementType }> = {
    New:       { label: 'New',       color: 'text-blue-600 dark:text-blue-400',   bgColor: 'bg-blue-500',   icon: Target },
    Contacted: { label: 'Contacted', color: 'text-yellow-600 dark:text-yellow-400', bgColor: 'bg-yellow-500', icon: Users },
    Qualified: { label: 'Qualified', color: 'text-green-600 dark:text-green-400',  bgColor: 'bg-green-500',  icon: TrendingUp },
    Lost:      { label: 'Lost',      color: 'text-red-600 dark:text-red-400',      bgColor: 'bg-red-500',    icon: XCircle },
  };

  const sourceConfig: Record<string, { label: string; color: string; bgColor: string; icon: React.ElementType }> = {
    Website:   { label: 'Website',   color: 'text-purple-600 dark:text-purple-400', bgColor: 'bg-purple-500', icon: Globe },
    Instagram: { label: 'Instagram', color: 'text-pink-600 dark:text-pink-400',     bgColor: 'bg-pink-500',   icon: Instagram },
    Referral:  { label: 'Referral',  color: 'text-orange-600 dark:text-orange-400', bgColor: 'bg-orange-500', icon: Share2 },
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center min-h-[60vh]">
        <Spinner size="lg" className="text-brand-600" />
      </div>
    );
  }

  const total = stats?.total ?? 0;

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="mb-8">
        <h1 className="text-2xl font-bold tracking-tight">Analytics</h1>
        <p className="text-gray-500 dark:text-gray-400 mt-1 text-sm">
          Overview of your leads pipeline
        </p>
      </div>

      {/* Total */}
      <div className="card p-6 mb-6 flex items-center gap-5 animate-slide-up">
        <div className="w-14 h-14 rounded-2xl bg-brand-100 dark:bg-brand-900/30 flex items-center justify-center">
          <Users className="w-7 h-7 text-brand-600 dark:text-brand-400" />
        </div>
        <div>
          <p className="text-sm text-gray-500 dark:text-gray-400">Total Leads</p>
          <p className="text-4xl font-bold tracking-tight mt-0.5">{total}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Status Breakdown */}
        <div className="card p-6 animate-slide-up">
          <h2 className="font-semibold mb-5 flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-brand-600" />
            By Status
          </h2>
          <div className="space-y-4">
            {['New', 'Contacted', 'Qualified', 'Lost'].map((status) => {
              const count = stats?.statusStats.find((s) => s._id === status)?.count ?? 0;
              const pct = total > 0 ? Math.round((count / total) * 100) : 0;
              const cfg = statusConfig[status];
              const Icon = cfg.icon;
              return (
                <div key={status} className="flex items-center gap-4">
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${cfg.bgColor} bg-opacity-15`}>
                    <Icon className={`w-4 h-4 ${cfg.color}`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex justify-between items-center mb-1.5">
                      <span className="text-sm font-medium">{cfg.label}</span>
                      <span className="text-sm text-gray-500 dark:text-gray-400">
                        {count} <span className="text-xs">({pct}%)</span>
                      </span>
                    </div>
                    <div className="h-2 bg-gray-100 dark:bg-gray-800 rounded-full overflow-hidden">
                      <div
                        className={`h-full ${cfg.bgColor} rounded-full transition-all duration-700`}
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Source Breakdown */}
        <div className="card p-6 animate-slide-up">
          <h2 className="font-semibold mb-5 flex items-center gap-2">
            <Globe className="w-4 h-4 text-brand-600" />
            By Source
          </h2>

          {stats?.sourceStats.length === 0 ? (
            <p className="text-sm text-gray-400 text-center py-8">No leads yet</p>
          ) : (
            <div className="space-y-4">
              {['Website', 'Instagram', 'Referral'].map((source) => {
                const count = stats?.sourceStats.find((s) => s._id === source)?.count ?? 0;
                const pct = total > 0 ? Math.round((count / total) * 100) : 0;
                const cfg = sourceConfig[source];
                const Icon = cfg.icon;
                return (
                  <div key={source} className="flex items-center gap-4">
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${cfg.bgColor} bg-opacity-15`}>
                      <Icon className={`w-4 h-4 ${cfg.color}`} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex justify-between items-center mb-1.5">
                        <span className="text-sm font-medium">{cfg.label}</span>
                        <span className="text-sm text-gray-500 dark:text-gray-400">
                          {count} <span className="text-xs">({pct}%)</span>
                        </span>
                      </div>
                      <div className="h-2 bg-gray-100 dark:bg-gray-800 rounded-full overflow-hidden">
                        <div
                          className={`h-full ${cfg.bgColor} rounded-full transition-all duration-700`}
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Status Cards Grid */}
        <div className="lg:col-span-2 grid grid-cols-2 sm:grid-cols-4 gap-4">
          {['New', 'Contacted', 'Qualified', 'Lost'].map((status) => {
            const count = stats?.statusStats.find((s) => s._id === status)?.count ?? 0;
            const pct = total > 0 ? Math.round((count / total) * 100) : 0;
            const cfg = statusConfig[status];
            const Icon = cfg.icon;
            return (
              <div key={status} className="card p-4 animate-fade-in">
                <div className={`w-9 h-9 rounded-xl flex items-center justify-center mb-3 ${cfg.bgColor} bg-opacity-10`}>
                  <Icon className={`w-4.5 h-4.5 ${cfg.color}`} />
                </div>
                <p className="text-2xl font-bold">{count}</p>
                <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">{cfg.label}</p>
                <p className={`text-xs font-medium mt-1 ${cfg.color}`}>{pct}% of total</p>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default StatsPage;
