import React from 'react';
import { Link } from 'react-router-dom';
import { Target, Home } from 'lucide-react';

const NotFoundPage: React.FC = () => (
  <div className="min-h-screen flex items-center justify-center p-4 bg-gray-50 dark:bg-gray-950">
    <div className="text-center animate-slide-up">
      <div className="inline-flex items-center justify-center w-16 h-16 bg-brand-100 dark:bg-brand-900/30 rounded-2xl mb-6">
        <Target className="w-8 h-8 text-brand-600 dark:text-brand-400" />
      </div>
      <h1 className="text-6xl font-bold text-gray-900 dark:text-gray-100 mb-4">404</h1>
      <p className="text-xl font-medium text-gray-700 dark:text-gray-300 mb-2">Page not found</p>
      <p className="text-gray-500 dark:text-gray-400 mb-8">
        The page you're looking for doesn't exist or has been moved.
      </p>
      <Link to="/dashboard" className="btn-primary inline-flex">
        <Home className="w-4 h-4" />
        Back to Dashboard
      </Link>
    </div>
  </div>
);

export default NotFoundPage;
