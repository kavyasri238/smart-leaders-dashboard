import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Users, TrendingUp, Target, XCircle, Plus, ArrowRight } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { leadsService } from '../services/leadsService';
import { LeadStats } from '../types';
import { Spinner } from '../components/ui/Spinner';

const DashboardPage: React.FC = () => {
  const { user } = useAuth();
  const [stats, setStats] = useState<LeadStats | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const res = await leadsService.getStats();
        if (res.success && res.data) {
          setStats(res.data);
        }
      } catch {
        // silently fail
      } finally {
        setIsLoading(false);
      }
    };
    fetchStats();
  }, []);

  const getStatusCount = (status: string) => {
    return stats?.statusStats.find((s) => s._id === status)?.count ?? 0;
  };

  const statCards = [
    {
      label: 'Total Leads',
      value: stats?.total ?? 0,
      icon: Users,
      color: 'bg-brand-50 dark:bg-brand-900/20 text-brand-600 dark:text-brand-400',
      iconBg: 'bg-brand-100 dark:bg-brand-900/40',
    },
    {
      label: 'New Leads',
      value: getStatusCount('New'),
      icon: Target,
      color: 'bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400',
      iconBg: 'bg-blue-100 dark:bg-blue-900/40',
    },
    {
      label: 'Qualified',
      value: getStatusCount('Qualified'),
      icon: TrendingUp,
      color: 'bg-green-50 dark:bg-green-900/20 text-green-600 dark:text-green-400',
      iconBg: 'bg-green-100 dark:bg-green-900/40',
    },
    {
      label: 'Lost',
      value: getStatusCount('Lost'),
      icon: XCircle,
      color: 'bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400',
      iconBg: 'bg-red-100 dark:bg-red-900/40',
    },
  ];

  return (
    <div className="p-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">
            Welcome back, {user?.name.split(' ')[0]} 👋
          </h1>
          <p className="text-gray-500 dark:text-gray-400 mt-1 text-sm">
            Here&apos;s what&apos;s happening with your leads today.
          </p>
        </div>
        <Link to="/leads" className="btn-primary">
          <Plus className="w-4 h-4" />
          <span className="hidden sm:inline">Add Lead</span>
        </Link>
      </div>

      {/* Stats Cards */}
      {isLoading ? (
        <div className="flex justify-center py-12">
          <Spinner size="lg" className="text-brand-600" />
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {statCards.map(({ label, value, icon: Icon, color, iconBg }) => (
            <div key={label} className="card p-5 animate-slide-up">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">{label}</p>
                  <p className="text-3xl font-bold mt-1">{value}</p>
                </div>
                <div className={`${iconBg} p-3 rounded-xl`}>
                  <Icon className={`w-5 h-5 ${color.split(' ').slice(-2).join(' ')}`} />
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Source & Status Breakdown */}
      {stats && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
          {/* Status Breakdown */}
          <div className="card p-5">
            <h2 className="font-semibold mb-4">Status Breakdown</h2>
            <div className="space-y-3">
              {['New', 'Contacted', 'Qualified', 'Lost'].map((status) => {
                const count = getStatusCount(status);
                const pct = stats.total > 0 ? Math.round((count / stats.total) * 100) : 0;
                const colors: Record<string, string> = {
                  New: 'bg-blue-500',
                  Contacted: 'bg-yellow-500',
                  Qualified: 'bg-green-500',
                  Lost: 'bg-red-500',
                };
                return (
                  <div key={status}>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-gray-600 dark:text-gray-400">{status}</span>
                      <span className="font-medium">{count} ({pct}%)</span>
                    </div>
                    <div className="h-2 bg-gray-100 dark:bg-gray-800 rounded-full overflow-hidden">
                      <div
                        className={`h-full ${colors[status]} rounded-full transition-all duration-700`}
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Source Breakdown */}
          <div className="card p-5">
            <h2 className="font-semibold mb-4">Source Breakdown</h2>
            <div className="space-y-3">
              {stats.sourceStats.map(({ _id: source, count }) => {
                const pct = stats.total > 0 ? Math.round((count / stats.total) * 100) : 0;
                const colors: Record<string, string> = {
                  Website: 'bg-purple-500',
                  Instagram: 'bg-pink-500',
                  Referral: 'bg-orange-500',
                };
                return (
                  <div key={source}>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-gray-600 dark:text-gray-400">{source}</span>
                      <span className="font-medium">{count} ({pct}%)</span>
                    </div>
                    <div className="h-2 bg-gray-100 dark:bg-gray-800 rounded-full overflow-hidden">
                      <div
                        className={`h-full ${colors[source] ?? 'bg-gray-500'} rounded-full transition-all duration-700`}
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                  </div>
                );
              })}
              {stats.sourceStats.length === 0 && (
                <p className="text-sm text-gray-400 text-center py-4">No data yet</p>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Quick Link */}
      <Link
        to="/leads"
        className="flex items-center justify-between card p-4 hover:shadow-md transition-shadow group"
      >
        <div>
          <p className="font-medium">Manage All Leads</p>
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-0.5">
            View, filter, and manage your complete leads list
          </p>
        </div>
        <ArrowRight className="w-5 h-5 text-gray-400 group-hover:text-brand-600 group-hover:translate-x-1 transition-all" />
      </Link>
    </div>
  );
};

export default DashboardPage;
