import React, { useState } from 'react';
import { Plus, Download, RefreshCw } from 'lucide-react';
import { useLeads } from '../hooks/useLeads';
import { useDebounce } from '../hooks/useDebounce';
import { Lead, LeadFormData } from '../types';
import { leadsService } from '../services/leadsService';
import { LeadTable } from '../components/leads/LeadTable';
import { LeadFiltersBar } from '../components/leads/LeadFiltersBar';
import { LeadForm } from '../components/leads/LeadForm';
import { LeadDetail } from '../components/leads/LeadDetail';
import { Modal } from '../components/ui/Modal';
import { ConfirmDialog } from '../components/ui/ConfirmDialog';
import { Pagination } from '../components/ui/Pagination';
import { Spinner } from '../components/ui/Spinner';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';
import { AxiosError } from 'axios';

const LeadsPage: React.FC = () => {
  const { user } = useAuth();
  const { leads, isLoading, error, meta, filters, setFilters, refetch, deleteLead } = useLeads();

  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [editingLead, setEditingLead] = useState<Lead | null>(null);
  const [viewingLead, setViewingLead] = useState<Lead | null>(null);
  const [deletingLead, setDeletingLead] = useState<Lead | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  const handleCreate = async (data: LeadFormData) => {
    setIsSubmitting(true);
    try {
      await leadsService.createLead(data);
      toast.success('Lead created successfully!');
      setIsCreateOpen(false);
      refetch();
    } catch (err) {
      const axiosErr = err as AxiosError<{ message: string }>;
      toast.error(axiosErr.response?.data?.message ?? 'Failed to create lead');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleUpdate = async (data: LeadFormData) => {
    if (!editingLead) return;
    setIsSubmitting(true);
    try {
      await leadsService.updateLead(editingLead._id, data);
      toast.success('Lead updated successfully!');
      setEditingLead(null);
      refetch();
    } catch (err) {
      const axiosErr = err as AxiosError<{ message: string }>;
      toast.error(axiosErr.response?.data?.message ?? 'Failed to update lead');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = async () => {
    if (!deletingLead) return;
    setIsDeleting(true);
    try {
      await deleteLead(deletingLead._id);
      setDeletingLead(null);
    } finally {
      setIsDeleting(false);
    }
  };

  const handleExport = () => {
    leadsService.exportCSV({
      status: filters.status,
      source: filters.source,
      search: filters.search,
    });
    toast.success('Exporting CSV...');
  };

  return (
    <div className="p-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Leads</h1>
          <p className="text-gray-500 dark:text-gray-400 mt-1 text-sm">
            {meta ? `${meta.total} total leads` : 'Manage your leads'}
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExport}
            className="btn-secondary text-sm py-2 px-3"
            title="Export CSV"
          >
            <Download className="w-4 h-4" />
            <span className="hidden sm:inline">Export CSV</span>
          </button>
          <button
            onClick={refetch}
            className="btn-secondary text-sm py-2 px-3"
            title="Refresh"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
          </button>
          <button onClick={() => setIsCreateOpen(true)} className="btn-primary text-sm">
            <Plus className="w-4 h-4" />
            <span className="hidden sm:inline">Add Lead</span>
          </button>
        </div>
      </div>

      {/* Leads Table Card */}
      <div className="card animate-fade-in">
        <LeadFiltersBar filters={filters} onFilterChange={setFilters} />

        {isLoading ? (
          <div className="flex justify-center py-16">
            <Spinner size="lg" className="text-brand-600" />
          </div>
        ) : error ? (
          <div className="flex flex-col items-center py-16 text-center">
            <p className="text-red-500 mb-3">{error}</p>
            <button onClick={refetch} className="btn-secondary text-sm">
              Try Again
            </button>
          </div>
        ) : (
          <>
            <LeadTable
              leads={leads}
              onEdit={(lead) => setEditingLead(lead)}
              onDelete={(lead) => setDeletingLead(lead)}
              onView={(lead) => setViewingLead(lead)}
            />
            {meta && (
              <Pagination
                meta={meta}
                onPageChange={(page) => setFilters({ page })}
              />
            )}
          </>
        )}
      </div>

      {/* Create Modal */}
      <Modal
        isOpen={isCreateOpen}
        onClose={() => setIsCreateOpen(false)}
        title="Create New Lead"
      >
        <LeadForm
          onSubmit={handleCreate}
          onCancel={() => setIsCreateOpen(false)}
          isLoading={isSubmitting}
        />
      </Modal>

      {/* Edit Modal */}
      <Modal
        isOpen={!!editingLead}
        onClose={() => setEditingLead(null)}
        title="Edit Lead"
      >
        <LeadForm
          initialData={editingLead ?? undefined}
          onSubmit={handleUpdate}
          onCancel={() => setEditingLead(null)}
          isLoading={isSubmitting}
        />
      </Modal>

      {/* View Detail */}
      <LeadDetail
        lead={viewingLead}
        isOpen={!!viewingLead}
        onClose={() => setViewingLead(null)}
        onEdit={(lead) => {
          setViewingLead(null);
          setEditingLead(lead);
        }}
      />

      {/* Delete Confirm */}
      {user?.role === 'admin' && (
        <ConfirmDialog
          isOpen={!!deletingLead}
          onClose={() => setDeletingLead(null)}
          onConfirm={handleDelete}
          title="Delete Lead"
          message={`Are you sure you want to delete "${deletingLead?.name}"? This action cannot be undone.`}
          isLoading={isDeleting}
        />
      )}
    </div>
  );
};

export default LeadsPage;
