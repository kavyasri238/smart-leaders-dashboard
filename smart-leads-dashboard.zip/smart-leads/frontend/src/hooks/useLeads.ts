import { useState, useEffect, useCallback } from 'react';
import { Lead, LeadFilters, PaginationMeta } from '../types';
import { leadsService } from '../services/leadsService';
import toast from 'react-hot-toast';

interface UseLeadsReturn {
  leads: Lead[];
  isLoading: boolean;
  error: string | null;
  meta: PaginationMeta | null;
  filters: LeadFilters;
  setFilters: (filters: Partial<LeadFilters>) => void;
  refetch: () => void;
  deleteLead: (id: string) => Promise<void>;
}

const defaultFilters: LeadFilters = {
  status: '',
  source: '',
  search: '',
  sort: 'latest',
  page: 1,
  limit: 10,
};

export const useLeads = (): UseLeadsReturn => {
  const [leads, setLeads] = useState<Lead[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [meta, setMeta] = useState<PaginationMeta | null>(null);
  const [filters, setFiltersState] = useState<LeadFilters>(defaultFilters);

  const fetchLeads = useCallback(async () => {
    try {
      setIsLoading(true);
      setError(null);
      const res = await leadsService.getLeads(filters);
      if (res.success && res.data) {
        setLeads(res.data.leads);
        setMeta(res.meta ?? null);
      }
    } catch {
      setError('Failed to fetch leads. Please try again.');
    } finally {
      setIsLoading(false);
    }
  }, [filters]);

  useEffect(() => {
    fetchLeads();
  }, [fetchLeads]);

  const setFilters = (newFilters: Partial<LeadFilters>) => {
    setFiltersState((prev) => ({
      ...prev,
      ...newFilters,
      // Reset to page 1 if filters change (except page itself)
      page: 'page' in newFilters ? (newFilters.page ?? 1) : 1,
    }));
  };

  const deleteLead = async (id: string) => {
    try {
      await leadsService.deleteLead(id);
      toast.success('Lead deleted successfully');
      fetchLeads();
    } catch {
      toast.error('Failed to delete lead');
    }
  };

  return {
    leads,
    isLoading,
    error,
    meta,
    filters,
    setFilters,
    refetch: fetchLeads,
    deleteLead,
  };
};
