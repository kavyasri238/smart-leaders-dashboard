import React, { ReactNode } from 'react';
import { Navbar } from './Navbar';

interface LayoutProps {
  children: ReactNode;
}

export const Layout: React.FC<LayoutProps> = ({ children }) => (
  <div className="flex min-h-screen">
    <Navbar />
    <main className="flex-1 lg:overflow-y-auto">
      <div className="pt-14 lg:pt-0 min-h-screen">{children}</div>
    </main>
  </div>
);
