import React from 'react';
import { Lead } from '../../types';
import { Modal } from '../ui/Modal';
import { StatusBadge, SourceBadge } from '../ui/Badge';
import { Calendar, Mail, User, FileText } from 'lucide-react';

interface LeadDetailProps {
  lead: Lead | null;
  isOpen: boolean;
  onClose: () => void;
  onEdit: (lead: Lead) => void;
}

export const LeadDetail: React.FC<LeadDetailProps> = ({
  lead,
  isOpen,
  onClose,
  onEdit,
}) => {
  if (!lead) return null;

  const formatDate = (dateStr: string) =>
    new Date(dateStr).toLocaleDateString('en-US', {
      month: 'long',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Lead Details" size="md">
      <div className="space-y-5">
        {/* Header */}
        <div className="flex items-start justify-between">
          <div>
            <h3 className="text-xl font-semibold">{lead.name}</h3>
            <div className="flex items-center gap-1.5 mt-1 text-sm text-gray-500 dark:text-gray-400">
              <Mail className="w-3.5 h-3.5" />
              {lead.email}
            </div>
          </div>
          <div className="flex flex-col items-end gap-2">
            <StatusBadge status={lead.status} />
            <SourceBadge source={lead.source} />
          </div>
        </div>

        {/* Meta */}
        <div className="grid grid-cols-2 gap-4 p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
          <div>
            <div className="flex items-center gap-1.5 text-xs text-gray-500 dark:text-gray-400 mb-1">
              <User className="w-3 h-3" />
              Created By
            </div>
            <p className="text-sm font-medium">{lead.createdBy?.name ?? 'Unknown'}</p>
          </div>
          <div>
            <div className="flex items-center gap-1.5 text-xs text-gray-500 dark:text-gray-400 mb-1">
              <Calendar className="w-3 h-3" />
              Created At
            </div>
            <p className="text-sm font-medium">{formatDate(lead.createdAt)}</p>
          </div>
        </div>

        {/* Notes */}
        {lead.notes && (
          <div>
            <div className="flex items-center gap-1.5 text-xs font-medium text-gray-500 dark:text-gray-400 mb-2">
              <FileText className="w-3 h-3" />
              Notes
            </div>
            <p className="text-sm text-gray-700 dark:text-gray-300 bg-gray-50 dark:bg-gray-800 rounded-lg p-3 leading-relaxed">
              {lead.notes}
            </p>
          </div>
        )}

        <div className="flex gap-3 pt-2">
          <button onClick={onClose} className="btn-secondary flex-1 justify-center">
            Close
          </button>
          <button
            onClick={() => {
              onClose();
              onEdit(lead);
            }}
            className="btn-primary flex-1 justify-center"
          >
            Edit Lead
          </button>
        </div>
      </div>
    </Modal>
  );
};
