import React, { useState, useEffect } from 'react';
import { Search, SlidersHorizontal, X } from 'lucide-react';
import { LeadFilters, LeadStatus, LeadSource, SortOrder } from '../../types';
import { useDebounce } from '../../hooks/useDebounce';

interface LeadFiltersBarProps {
  filters: LeadFilters;
  onFilterChange: (filters: Partial<LeadFilters>) => void;
}

const statusOptions: Array<{ value: LeadStatus | ''; label: string }> = [
  { value: '', label: 'All Statuses' },
  { value: 'New', label: 'New' },
  { value: 'Contacted', label: 'Contacted' },
  { value: 'Qualified', label: 'Qualified' },
  { value: 'Lost', label: 'Lost' },
];

const sourceOptions: Array<{ value: LeadSource | ''; label: string }> = [
  { value: '', label: 'All Sources' },
  { value: 'Website', label: 'Website' },
  { value: 'Instagram', label: 'Instagram' },
  { value: 'Referral', label: 'Referral' },
];

const sortOptions: Array<{ value: SortOrder; label: string }> = [
  { value: 'latest', label: 'Latest First' },
  { value: 'oldest', label: 'Oldest First' },
];

export const LeadFiltersBar: React.FC<LeadFiltersBarProps> = ({
  filters,
  onFilterChange,
}) => {
  const [searchInput, setSearchInput] = useState(filters.search ?? '');
  const debouncedSearch = useDebounce(searchInput, 400);

  useEffect(() => {
    onFilterChange({ search: debouncedSearch });
  }, [debouncedSearch]); // eslint-disable-line react-hooks/exhaustive-deps

  const hasActiveFilters =
    filters.status || filters.source || filters.search;

  const clearAll = () => {
    setSearchInput('');
    onFilterChange({ status: '', source: '', search: '', sort: 'latest' });
  };

  return (
    <div className="flex flex-col sm:flex-row gap-3 p-4 border-b border-gray-100 dark:border-gray-800">
      {/* Search */}
      <div className="relative flex-1 min-w-0">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
        <input
          type="text"
          value={searchInput}
          onChange={(e) => setSearchInput(e.target.value)}
          className="input-field pl-9 pr-4"
          placeholder="Search by name or email..."
        />
        {searchInput && (
          <button
            onClick={() => setSearchInput('')}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      {/* Filters Row */}
      <div className="flex items-center gap-2 flex-wrap">
        <SlidersHorizontal className="w-4 h-4 text-gray-400 hidden sm:block" />

        <select
          value={filters.status ?? ''}
          onChange={(e) => onFilterChange({ status: e.target.value as LeadStatus | '' })}
          className="input-field w-auto text-sm py-2"
        >
          {statusOptions.map(({ value, label }) => (
            <option key={label} value={value}>{label}</option>
          ))}
        </select>

        <select
          value={filters.source ?? ''}
          onChange={(e) => onFilterChange({ source: e.target.value as LeadSource | '' })}
          className="input-field w-auto text-sm py-2"
        >
          {sourceOptions.map(({ value, label }) => (
            <option key={label} value={value}>{label}</option>
          ))}
        </select>

        <select
          value={filters.sort ?? 'latest'}
          onChange={(e) => onFilterChange({ sort: e.target.value as SortOrder })}
          className="input-field w-auto text-sm py-2"
        >
          {sortOptions.map(({ value, label }) => (
            <option key={value} value={value}>{label}</option>
          ))}
        </select>

        {hasActiveFilters && (
          <button
            onClick={clearAll}
            className="flex items-center gap-1.5 px-3 py-2 text-sm text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
          >
            <X className="w-3.5 h-3.5" />
            Clear
          </button>
        )}
      </div>
    </div>
  );
};
